package com.example.rupizza.RuPizza;

public enum Sauce {
    TOMATO, ALFREDO
}
