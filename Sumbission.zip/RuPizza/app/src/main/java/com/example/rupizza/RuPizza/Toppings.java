package com.example.rupizza.RuPizza;

public enum Toppings {
    SAUSAGE, PEPPERONI, GREEN_PEPPER, ONION, MUSHROOM,
    HAM, BLACK_OLIVE, BEEF, SHRIMP, SQUID, CRAB_MEAT
}
